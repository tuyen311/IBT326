# Cách đưa lên Vercel (chỉ 3 bước)

Thư mục gồm `index.html` (website) và `api/state.js` (lưu bài nộp, deadline, nhắc nhở dùng chung cho mọi máy).

1. **Đưa lên Vercel.** Tạo repo GitHub, bấm *Add file → Upload files*, kéo cả thư mục này vào. Sau đó vào vercel.com → *Add New → Project* → chọn repo → *Deploy* (không cần chỉnh gì).
2. **Bật lưu trữ (1 lần duy nhất).** Trong project Vercel: tab **Storage** → *Create Database* → chọn **Upstash Redis** → chọn gói Free → *Connect to Project*. Rồi vào tab **Deployments** → bấm *Redeploy*.
3. **Tạo PIN giáo viên.** Mở link website → kéo xuống cuối trang → bấm **Teacher panel** → nhập một PIN bạn chọn (lần đầu sẽ tự lưu làm PIN của bạn). Làm bước này ngay sau khi deploy xong, trước khi gửi link cho sinh viên.

Xong. Sinh viên mở link ở máy nào cũng thấy cùng một bảng 6 nhóm, tự cập nhật mỗi 15 giây.

## Dùng trong lớp
- Đặt deadline: Teacher panel → bấm +10 / +30 / +60 phút hoặc chọn giờ.
- Nhắc nhở: bấm **Send reminder now**. Mọi trang sinh viên đang mở sẽ hiện pop-up kèm danh sách nhóm chưa nộp.

## Chế độ demo
Nếu chưa bật Storage, website ghi chú "Demo mode" và chỉ lưu trong trình duyệt đó (PIN demo: `1234`).
