// Vercel Serverless Function: /api/state
// Storage: Upstash Redis (added in 1 click from Vercel > Storage). No other settings needed.
// The teacher PIN is created inside the website the first time the teacher opens the Teacher panel.

const crypto = require('crypto');
const BASE = process.env.KV_REST_API_URL || process.env.UPSTASH_REDIS_REST_URL;
const TOKEN = process.env.KV_REST_API_TOKEN || process.env.UPSTASH_REDIS_REST_TOKEN;
const GROUPS = 6;

async function pipe(cmds) {
  const r = await fetch(BASE.replace(/\/$/, '') + '/pipeline', {
    method: 'POST',
    headers: { Authorization: 'Bearer ' + TOKEN, 'Content-Type': 'application/json' },
    body: JSON.stringify(cmds),
  });
  const j = await r.json();
  if (!Array.isArray(j)) throw new Error('storage error');
  return j.map((x) => {
    if (x.error) throw new Error(x.error);
    return x.result;
  });
}
const toObj = (arr) => {
  const o = {};
  for (let i = 0; i < (arr || []).length; i += 2) o[arr[i]] = arr[i + 1];
  return o;
};
const hash = (p) => crypto.createHash('sha256').update('s6:' + p).digest('hex');

async function load() {
  const [subsRaw, metaRaw] = await pipe([['HGETALL', 's6:subs'], ['HGETALL', 's6:meta']]);
  const subs = {};
  const s = toObj(subsRaw);
  for (const g in s) { try { subs[g] = JSON.parse(s[g]); } catch (e) {} }
  const m = toObj(metaRaw);
  let reminder = null;
  try { reminder = m.reminder ? JSON.parse(m.reminder) : null; } catch (e) {}
  return { deadline: m.deadline || null, reminder, subs, pinSet: !!m.pin, _pin: m.pin };
}
const publicState = (st) => ({ deadline: st.deadline, reminder: st.reminder, subs: st.subs, pinSet: st.pinSet });

module.exports = async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  if (!BASE || !TOKEN) return res.status(503).json({ error: 'Storage not connected yet' });

  try {
    if (req.method === 'GET') return res.status(200).json(publicState(await load()));
    if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

    const b = typeof req.body === 'string' ? JSON.parse(req.body || '{}') : req.body || {};

    if (b.action === 'submit') {
      const g = parseInt(b.group, 10);
      const mnc = String(b.mnc || '').trim().slice(0, 80);
      const url = String(b.url || '').trim().slice(0, 500);
      if (!(g >= 1 && g <= GROUPS)) return res.status(400).json({ error: 'Invalid group' });
      if (!mnc) return res.status(400).json({ error: 'Please enter your MNC name' });
      if (!/^https?:\/\/[^\s]+$/i.test(url)) return res.status(400).json({ error: 'Link must start with http:// or https://' });
      const st = await load();
      const now = Date.now();
      const rec = { mnc, url, ts: now, late: !!(st.deadline && now > Date.parse(st.deadline)) };
      await pipe([['HSET', 's6:subs', String(g), JSON.stringify(rec)]]);
      return res.status(200).json({ state: publicState(await load()) });
    }

    // ---- Teacher actions ----
    const st = await load();
    const pin = String(b.pin || '');
    if (!st._pin) {
      // first time: whoever sets the PIN becomes the teacher
      if (pin.length < 4) return res.status(400).json({ error: 'Create a PIN with at least 4 characters' });
      await pipe([['HSET', 's6:meta', 'pin', hash(pin)]]);
    } else if (hash(pin) !== st._pin) {
      return res.status(401).json({ error: 'Wrong PIN' });
    }

    if (b.action === 'setDeadline') {
      const t = Date.parse(b.deadline);
      if (b.deadline && !isNaN(t)) await pipe([['HSET', 's6:meta', 'deadline', new Date(t).toISOString()]]);
      else await pipe([['HDEL', 's6:meta', 'deadline']]);
    } else if (b.action === 'remind') {
      await pipe([['HSET', 's6:meta', 'reminder', JSON.stringify({ id: Date.now(), msg: String(b.msg || '').slice(0, 200) })]]);
    } else if (b.action === 'clearSub') {
      await pipe([['HDEL', 's6:subs', String(parseInt(b.group, 10))]]);
    } else if (b.action === 'reset') {
      await pipe([['DEL', 's6:subs'], ['HDEL', 's6:meta', 'deadline'], ['HDEL', 's6:meta', 'reminder']]);
    } else if (b.action !== 'check') {
      return res.status(400).json({ error: 'Unknown action' });
    }
    return res.status(200).json({ state: publicState(await load()) });
  } catch (e) {
    return res.status(500).json({ error: 'Server error' });
  }
};
